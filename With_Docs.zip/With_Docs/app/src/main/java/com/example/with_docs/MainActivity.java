package com.example.with_docs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView mWelcomeText, mPartnerShipText;
    Button mContinueButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        mWelcomeText=findViewById(R.id.welcometext);
        mPartnerShipText=findViewById(R.id.partnershiptext);
        mContinueButton=findViewById(R.id.continuebutton);
        String text="<h1 style ='font-family:SfProDisplay; font-weight=bold; font-size:20px;'><font color='#F5A623'>Welcome to With-Doc's</font></h1><br><p style ='font-family:Sf Pro Text;'><font color='#F5A623' >Use With-Docs to create your Doctors Profile. Manage unknown Patients who want to opt for an A,Y,U,S,H treatment with/instead Modern Medicine but unaware of Your Clinic rather being in the same locality / nearby town.</font></p>";
        String text1="<p style ='font-family:Sf Pro;font color=0E210E'> This is a partnership with Upcloud Technology and NIMA where this company is the Digital Healthcare Service provider for the association & all the members in it. This Digital Service includes an App for Doctor & a Software to manage their Practice efficiently generating an EMR in return.</p>";
        mWelcomeText.setPadding(0,0,0,600);
        mWelcomeText.setText(Html.fromHtml(text));
        mPartnerShipText.setText(Html.fromHtml(text1));
        mContinueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this,Main2Activity.class);
                startActivity(i);
            }
        });
    }
}
