package com.example.with_docs;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PartnerShipInfo extends AppCompatActivity {
    EditText et_name, et_dob, et_state, et_city, et_homeaddr, et_pc, et_apc, et_caddr, et_ccn, et_accn;
    Button mContinue;
    DatabaseReference rootRef,demoRef;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getSupportActionBar().hide();
        setContentView(R.layout.activity_partner_ship_info);
        mContinue=findViewById(R.id.continue2);
        et_name = findViewById(R.id.fname);
        et_dob = findViewById(R.id.dob);
        et_state = findViewById(R.id.state);
        et_city = findViewById(R.id.city);
        et_homeaddr = findViewById(R.id.homeaddr);
        et_pc = findViewById(R.id.pcontant);
        et_apc = findViewById(R.id.pcontant2);
        et_caddr = findViewById(R.id.caddres);
        et_ccn = findViewById(R.id.ccontact);
        et_accn = findViewById(R.id.ccontact2);



        rootRef = FirebaseDatabase.getInstance().getReference();
        demoRef = rootRef.child("Info");



        mContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String value = et_name.getText().toString();
                String value1 = et_dob.getText().toString();
                String value2 = et_state.getText().toString();
                String value3 = et_city.getText().toString();
                String value4 = et_homeaddr.getText().toString();
                String value5 = et_pc.getText().toString();
                String value6 = et_apc.getText().toString();
                String value7 = et_city.getText().toString();
                String value8 = et_ccn.getText().toString();
                String value9 = et_accn.getText().toString();


                demoRef.push().setValue(value);

            }
        });


    }

}
