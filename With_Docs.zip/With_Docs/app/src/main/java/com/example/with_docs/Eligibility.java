package com.example.with_docs;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Eligibility extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eligibility);
        this.getSupportActionBar().hide();

    }
}
